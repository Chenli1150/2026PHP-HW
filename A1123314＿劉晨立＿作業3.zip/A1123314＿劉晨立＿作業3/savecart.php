<?php
session_start();

if (isset($_POST['nBuy']) && isset($_POST['uNum'])) {
    $selected_item = $_POST['nBuy'];
    $selected_num = (int)$_POST['uNum'];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // --- 修正後的合併邏輯 ---
    // 直接用商品名稱當作 Key，這樣就不會產生重複的列
    if (isset($_SESSION['cart'][$selected_item])) {
        $_SESSION['cart'][$selected_item] += $selected_num; // 數量累加
    } else {
        $_SESSION['cart'][$selected_item] = $selected_num; // 新增商品
    }

    header("Location: shoppingcart.php");
    exit();
} else {
    header("Location: index.php");
    exit();
}
?>