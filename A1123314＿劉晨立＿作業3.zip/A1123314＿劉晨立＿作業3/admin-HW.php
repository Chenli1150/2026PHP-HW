<?php
session_start();
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系統核心管理</title>
    <style>
        body {
            font-family: "Segoe UI", "Microsoft JhengHei", sans-serif;
            background-color: #1a202c; /* 深色背景 */
            color: #e2e8f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .admin-box {
            background: #2d3748;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
            text-align: center;
            border-left: 10px solid #ecc94b; /* 管理者金黃色辨識條 */
            position: relative;
            max-width: 500px;
            width: 90%;
        }
        .badge {
            position: absolute;
            top: 20px;
            right: 20px;
            background: #ecc94b;
            color: #1a202c;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        h1 {
            font-size: 32px;
            margin-bottom: 10px;
            letter-spacing: 2px;
        }
        .status-dot {
            height: 10px;
            width: 10px;
            background-color: #48bb78;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        p {
            color: #a0aec0;
            margin-bottom: 40px;
        }
        /* 管理動作按鈕 */
        .btn-group {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .btn {
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 6px;
            font-weight: 600;
            transition: all 0.2s;
        }
        .btn-primary {
            background-color: #ecc94b;
            color: #1a202c;
        }
        .btn-primary:hover {
            background-color: #f6e05e;
        }
        .btn-outline {
            border: 1px solid #4a5568;
            color: #a0aec0;
        }
        .btn-outline:hover {
            background: #4a5568;
            color: white;
        }
        /* 錯誤警告 */
        .error-title { color: #f56565; }
    </style>
</head>
<body>

<div class="admin-box">
    <?php
    if (isset($_SESSION['login']) && $_SESSION['login'] == 'admin') {
        echo "<div class='badge'>ROOT Access</div>";
        echo "<h1>Welcome! 管理者</h1>";
        echo "<p><span class='status-dot'></span>系統運行中 - 權限全開</p>";
        
        echo "<div class='btn-group'>";
        echo "<a href='#' class='btn btn-outline'>管理後台</a>";
        echo "<a href='logout.php' class='btn btn-primary'>登出系統</a>";
        echo "</div>";
    } else {
        // 非法進入
        echo "<h1 class='error-title'>⚠️ 系統警告</h1>";
        echo "<p>偵測到未經授權的存取行為。<br>您的 IP 已記錄，請立即離開。</p>";
        echo "<a href='0417HW.php' class='btn btn-primary'>返回登入頁</a>";
        
        header("Refresh:3;url=0417HW.php");
    }
    ?>
</div>

</body>
</html>