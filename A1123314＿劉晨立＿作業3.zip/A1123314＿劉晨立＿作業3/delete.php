<?php
session_start();

// 1. 檢查是否有收到要刪除的商品名稱
if (isset($_GET['item'])) {
    $item_to_delete = $_GET['item'];

    // 2. 使用 unset() 移除該商品
    if (isset($_SESSION['cart'][$item_to_delete])) {
        unset($_SESSION['cart'][$item_to_delete]);
    }
}

// 3. 刪除後跳回購物車清單
header("Location: shoppingcart.php");
exit();
?>