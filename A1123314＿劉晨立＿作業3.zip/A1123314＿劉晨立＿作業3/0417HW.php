<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>會員登入</title>
    <style>
        /* 基礎背景設定 */
        body {
            font-family: "Microsoft JhengHei", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        /* 登入卡片容器 */
        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 350px;
            text-align: center;
        }

        h2 {
            color: #333;
            margin-bottom: 25px;
        }

        /* 歡迎訊息樣式 */
        .welcome-msg {
            background-color: #e8f5e9;
            color: #2e7d32;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .del-link {
            display: block;
            margin-top: 5px;
            color: #d32f2f;
            text-decoration: none;
            font-size: 12px;
        }

        .del-link:hover {
            text-decoration: underline;
        }

        /* 表單欄位樣式 */
        .input-group {
            text-align: left;
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box; /* 確保寬度包含內邊距 */
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #764ba2;
            outline: none;
        }

        /* 按鈕樣式 */
        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #764ba2;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 10px;
        }

        input[type="submit"]:hover {
            background-color: #5a378d;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>會員登入</h2>

    <?php
    if(isset($_COOKIE['uName'])){
        echo "<div class='welcome-msg'>";
        echo "<strong>" . htmlspecialchars($_COOKIE['uName']) . "</strong> 歡迎回來！";
        echo "<a href='cookiedel.php' class='del-link'>[ 登出 / 刪除 Cookie ]</a>";
        echo "</div>";
    }
    ?>

    <form action="logincheck0417.php" method="POST">
        <div class="input-group">
            <label for="uName">帳號 (ID)</label>
            <input type="text" id="uName" name="uName" placeholder="請輸入帳號" required>
        </div>

        <div class="input-group">
            <label for="uPwd">密碼 (Password)</label>
            <input type="password" id="uPwd" name="uPwd" placeholder="請輸入密碼" required>
        </div>

        <input type="submit" value="立即登入">
    </form>
</div>

</body>
</html>