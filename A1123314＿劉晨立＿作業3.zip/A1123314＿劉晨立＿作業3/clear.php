<?php
session_start();
session_destroy();
echo "已清空，請重新從網頁選購";
header("Refresh:3;url=catalog.php");
?>