<?php

setcookie('uName', '', time()-100);
header("Refresh:0;url=login0410.php");




?>