<?php
session_start();

$fID='derrick';
$fPWD='12345';

$aID='admin';
$aPWD='123456';

$sID='student';
$sPWD='1234567';

$uID=$_POST['uName'];
$uPwd=$_POST['uPwd'];



$date = strtotime("+5 seconds", time());

if($uID==$fID && $uPwd==$fPWD){
    $_SESSION['login']='teacher';
    setcookie("uName", $uID, $date);
    header("Refresh:0;url=teacher.php");

}elseif($uID==$aID && $uPwd==$aPWD){
    $_SESSION['login']='admin';
    setcookie("uName", $uID, $date);
    header("Refresh:0;url=admin-HW.php");
   
}elseif($uID==$sID && $uPwd==$sPWD){
    $_SESSION['login']='student';
    setcookie("uName", $uID, $date);
    header("Refresh:0;url=student.php");
}else{
    echo "Loging Failed!";
    header("Refresh:3;url=0417HW.php");
}

?>