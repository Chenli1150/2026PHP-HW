<?php
session_start();
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>教師管理後台</title>
    <style>
        body {
            font-family: "Microsoft JhengHei", Arial, sans-serif;
            background: #eceff1; /* 輕盈的灰藍底色 */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .admin-card {
            background: white;
            padding: 50px;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            text-align: center;
            border-top: 8px solid #1a237e; /* 老師專用深藍色條 */
            max-width: 450px;
            width: 90%;
        }
        .icon {
            font-size: 50px;
            margin-bottom: 20px;
        }
        h1 {
            color: #1a237e;
            margin-bottom: 10px;
            font-size: 28px;
        }
        p {
            color: #546e7a;
            margin-bottom: 30px;
        }
        /* 按鈕設計 */
        .btn-logout {
            display: inline-block;
            padding: 12px 30px;
            background: #f44336;
            color: white;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            transition: 0.3s;
            box-shadow: 0 4px 10px rgba(244,67,54,0.3);
        }
        .btn-logout:hover {
            background: #d32f2f;
            transform: translateY(-2px);
        }
        /* 錯誤警告框 */
        .error-box {
            color: #b71c1c;
        }
        .timer {
            font-size: 14px;
            color: #90a4ae;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="admin-card">
    <?php
    // 檢查 Session：必須存在且身分為 teacher
    if (isset($_SESSION['login']) && $_SESSION['login'] == 'teacher') {
        echo "<div class='icon'>👨‍🏫</div>";
        echo "<h1>Welcome! 老師您好</h1>";
        echo "<p>這是您的專屬教學管理頁面。</p>";
        echo "<a href='logout.php' class='btn-logout'>登出系統</a>";
    } else {
        // 非老師身分或未登入
        echo "<div class='error-box'>";
        echo "<div class='icon'>⚠️</div>";
        echo "<h1>存取受限</h1>";
        echo "<p>您目前的權限無法查看此頁面內容。</p>";
        echo "<a href='0417HW.php' style='color:#1a237e; text-decoration:none; font-weight:bold;'>回登入頁面</a>";
        echo "<div class='timer'>3 秒後自動導向...</div>";
        echo "</div>";

        header("Refresh:3;url=0417HW.php");
    }
    ?>
</div>

</body>
</html>