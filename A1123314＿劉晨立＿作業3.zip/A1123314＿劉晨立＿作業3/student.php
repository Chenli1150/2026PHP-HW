<?php
session_start();
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系統驗證</title>
    <style>
        body {
            font-family: "Microsoft JhengHei", Arial, sans-serif;
            background: #f4f7f6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .message-card {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 400px;
        }
        .success h1 { color: #2e7d32; }
        .error h1 { color: #d32f2f; }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #764ba2;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
        }
        .btn:hover { background: #5a378d; }
        .timer { color: #888; font-size: 0.9em; margin-top: 15px; }
    </style>
</head>
<body>

<div class="message-card">
    <?php
    if (isset($_SESSION['login']) && $_SESSION['login'] == 'student') {
        // 登入成功
        echo "<div class='success'>";
        echo "<h1>👋 Welcome! 學生</h1>";
        echo "<p>您已成功進入學生專區。</p>";
        echo "<a href='logout.php' class='btn'>登出系統 (Logout)</a>";
        echo "</div>";
    } else {
        // 非法進入
        echo "<div class='error'>";
        echo "<h1>🚫 存取拒絕</h1>";
        echo "<p>非法進入網頁，您沒有權限查看此內容。</p>";
        echo "<div class='timer'>系統將在 3 秒後自動返回登入頁面...</div>";
        echo "<a href='0417HW.php' class='btn'>立即返回</a>";
        echo "</div>";
        
        // 設定跳轉
        header("Refresh:3;url=0417HW.php");
    }
    ?>
</div>

</body>
</html>