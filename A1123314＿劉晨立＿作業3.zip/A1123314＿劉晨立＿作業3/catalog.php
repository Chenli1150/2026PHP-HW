<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>零食選購商店</title>
    <style>
        /* 基礎設置 */
        body {
            font-family: "Microsoft JhengHei", sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* 購物卡片外框 */
        .shop-card {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 350px;
            text-align: center;
        }

        h2 { color: #333; margin-bottom: 1.5rem; }

        /* 表單元素美化 */
        select, input[type="number"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box; /* 確保寬度包含 padding */
            font-size: 1rem;
        }

        /* 按鈕美化 */
        input[type="submit"] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1rem;
            transition: background 0.3s;
            margin-top: 10px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        /* 連結按鈕化 */
        .nav-links {
            margin-top: 20px;
            font-size: 0.9rem;
        }

        .nav-links a {
            text-decoration: none;
            color: #666;
            margin: 0 10px;
        }

        .nav-links a:hover { color: #2196F3; }

        .btn-clear {
            display: inline-block;
            margin-top: 15px;
            color: #ff5252 !important;
            border: 1px solid #ff5252;
            padding: 5px 10px;
            border-radius: 5px;
        }
        
        .btn-clear:hover {
            background: #ff5252;
            color: white !important;
        }
    </style>
</head>
<body>

<div class="shop-card">
    <h2>🍪 零食小舖</h2>
    
    <form action="savecart.php" method="POST">
        <label for="nBuy">挑選喜歡的零食：</label>
        <select name="nBuy" id="nBuy">
            <option value="candy">🍬 糖果</option>
            <option value="cookies">🍪 餅乾</option>
            <option value="mountain_cookie" selected>⛰️ 山餅乾</option>
            <option value="drinks">🥤 飲料</option>
        </select>

        <label for="uNum">購買數量：</label>
        <input type="number" name="uNum" id="uNum" value="1" min="1">

        <input type="submit" value="加入購物車">
    </form>

    <div class="nav-links">
        <a href="shoppingcart.php">🛒 查看購物車</a>
        <br>
        <a href="clear.php" class="btn-clear">⚠️ 清空 Session</a>
    </div>
</div>

</body>
</html>