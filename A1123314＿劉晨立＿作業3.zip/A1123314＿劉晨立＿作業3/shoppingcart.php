<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>您的購物清單</title>
    <style>
        body {
            font-family: "Microsoft JhengHei", sans-serif;
            background-color: #f4f7f6;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 50px;
            margin: 0;
        }

        h2 { color: #333; margin-bottom: 20px; }

        /* 表格容器 */
        .cart-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 80%;
            max-width: 600px;
        }

        /* 表格本體 */
        table {
            width: 100%;
            border-collapse: collapse; /* 讓邊框合併，變得很乾淨 */
            margin-bottom: 20px;
        }

        th {
            background-color: #f8f9fa;
            color: #555;
            font-weight: bold;
            padding: 15px;
            border-bottom: 2px solid #eee;
            text-align: left;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            color: #666;
        }

        /* 滑鼠滑過列的時候變色 */
        tr:hover {
            background-color: #fdfdfd;
        }

        /* 刪除連結美化 */
        .btn-delete {
            color: #ff5252;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border: 1px solid #ff5252;
            border-radius: 5px;
            transition: 0.3s;
        }

        .btn-delete:hover {
            background-color: #ff5252;
            color: white;
        }

        /* 底部按鈕 */
        .footer-links {
            text-align: center;
            margin-top: 20px;
        }

        .btn-back {
            text-decoration: none;
            color: #2196F3;
            font-weight: bold;
        }

        .empty-msg {
            text-align: center;
            color: #999;
            font-size: 1.2rem;
            padding: 40px 0;
        }
    </style>
</head>
<body>

<div class="cart-container">
    <h2>🛒 您的購物清單</h2>

    <?php
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        echo "<table>";
        echo "<thead><tr><th>商品名稱</th><th>數量</th><th>操作</th></tr></thead>";
        echo "<tbody>";

        foreach ($_SESSION['cart'] as $item => $qty) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($item) . "</td>";
            echo "<td>" . htmlspecialchars($qty) . "</td>";
            echo "<td><a href='delete.php?item=" . urlencode($item) . "' class='btn-delete'>刪除</a></td>";
            echo "</tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<div class='empty-msg'>購物車目前空空如也... 😱</div>";
    }
    ?>

    <div class="footer-links">
        <a href="catalog.php" class="btn-back">⬅️ 繼續購物</a>
    </div>
</div>

</body>
</html>