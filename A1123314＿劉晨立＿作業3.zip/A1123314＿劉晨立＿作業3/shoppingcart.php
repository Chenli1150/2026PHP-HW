<?php
session_start();

echo "<h2>您的購物清單</h2>";

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>商品名稱</th><th>選購數量</th><th>操作</th></tr>"; // 新增「操作」欄位

    foreach ($_SESSION['cart'] as $item => $qty) {
        echo "<tr>";
        echo "<td>" . $item . "</td>";
        echo "<td>" . $qty . "</td>";
        // 新增刪除連結，將商品名稱傳給 delitem.php
        echo "<td><a href='delete.php?item=" . $item . "'>刪除</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "購物車是空的！";
}

echo "<br/><a href='catalog.php'>繼續購物</a>";
?>